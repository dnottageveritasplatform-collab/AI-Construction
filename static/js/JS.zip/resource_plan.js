/**
 * resource_plan.js
 * ----------------
 * Wrapped in an IIFE so every declaration lives in a private scope.
 * This prevents name collisions with utils.js or any other globally-loaded
 * script, which would throw a SyntaxError in strict mode and silently kill
 * the entire file before a single line of our code runs.
 *
 * window.xxx assignments expose the functions that HTML onclick / ondragover
 * attributes need.
 */
(function () {
"use strict";


/* ================================================================== */
/*  Utilities                                                           */
/* ================================================================== */

let _toastTimer;

/**
 * Show a brief toast notification.
 * @param {string} msg
 * @param {"info"|"success"|"warning"|"error"} type
 */
function showToast(msg, type = "info") {
    const el = document.getElementById("toast");
    if (!el) return;
    el.textContent = msg;
    el.className = `show ${type}`;
    clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => { el.className = ""; }, 3200);
}

/* ================================================================== */
/*  Project context (shared localStorage with Dashboard / Safety)      */
/* ================================================================== */

const RP_USER_ID = "usr-001";
const _rpSP = new URLSearchParams(window.location.search);
let rpActiveProjectId =
    (window.VeritasProjectContext?.parseFromUrl(_rpSP)) ||
    (window.VeritasProjectContext?.readPersisted()) ||
    "";

function getRpTasksStorageKey() {
    return `veritas_rp_tasks_v1_${rpActiveProjectId || "default"}`;
}

/** Append ?project_id= for /api/dashboard/tasks when a project is active. */
function rpApiUrl(path) {
    const sep = path.includes("?") ? "&" : "?";
    return rpActiveProjectId
        ? `${path}${sep}project_id=${encodeURIComponent(rpActiveProjectId)}`
        : path;
}

async function loadResourcePlanProjectSwitcher() {
    if (!window.VeritasProjectContext) return;
    const wrap = document.getElementById("projectSwitcher");
    if (!wrap) return;
    try {
        const projects = await VeritasProjectContext.fetchProjectsList(RP_USER_ID);
        if (!projects.length) return;

        rpActiveProjectId = VeritasProjectContext.resolveActiveId(projects, rpActiveProjectId);
        if (!rpActiveProjectId) return;

        window.VeritasProjectContext.writePersisted(rpActiveProjectId);
        const url = new URL(window.location.href);
        url.searchParams.set("project_id", rpActiveProjectId);
        window.history.replaceState({}, "", url);

        wrap.innerHTML = `
            <select id="projectSelect" onchange="switchResourcePlanProject(this.value)"
                style="background:var(--bg-card);color:var(--text-main);
                       border:1px solid var(--border);padding:6px 12px;
                       border-radius:8px;font-size:0.85rem;cursor:pointer;min-width:220px;">
                ${projects.map(p => `
                    <option value="${p.id}" ${p.id === rpActiveProjectId ? "selected" : ""}>
                        ${p.name} · ${p.completion}%
                    </option>
                `).join("")}
            </select>
        `;
    } catch (e) {
        console.warn("[Resource Plan Switcher] Could not load projects:", e);
    }
}

async function switchResourcePlanProject(projectId) {
    rpActiveProjectId = projectId;
    window.VeritasProjectContext?.writePersisted(projectId);
    const sel = document.getElementById("projectSelect");
    if (sel && sel.value !== projectId) sel.value = projectId;
    const url = new URL(window.location.href);
    url.searchParams.set("project_id", projectId);
    window.history.replaceState({}, "", url);
    updateResourcePlanNavLinks();
    tasks = loadTasks();
    renderBoard();
    await syncTasksFromAPI();
    showToast("Switched project context.", "info");
}

function updateResourcePlanNavLinks() {
    const pid = encodeURIComponent(rpActiveProjectId);
    const home = document.getElementById("navLinkHome");
    const recent = document.getElementById("navLinkRecentAlerts");
    const rp = document.getElementById("navLinkResourcePlan");
    const vr = document.getElementById("navLinkVrTraining");
    const rl = document.getElementById("navLinkResourciist");
    if (home) {
        home.href = rpActiveProjectId ? `/dashboard?project=${pid}` : "/dashboard";
    }
    if (recent) {
        recent.href = rpActiveProjectId ? `/safety?project_id=${pid}` : "/safety";
    }
    if (rp) {
        rp.href = rpActiveProjectId ? `/resource-plan?project_id=${pid}` : "/resource-plan";
    }
    if (vr) {
        vr.href = rpActiveProjectId ? `/vr-training?project_id=${pid}` : "/vr-training";
    }
    if (rl) {
        rl.href = rpActiveProjectId ? `/resourciist?project_id=${pid}` : "/resourciist";
    }
}

window.switchResourcePlanProject = switchResourcePlanProject;

/* ================================================================== */
/*  Task Data  (UC-04 — static seed, overridden by API on init)        */
/* ================================================================== */

const TASK_SEED = [
    {
        id: "t1", name: "Concrete Pouring",
        desc: "Pour foundation slab for Zones 2–4. Ensure correct mix ratio (Type S) and adequate curing time before next phase begins.",
        status: "in_progress", schedule_pct: 85, days_remaining: 3,
        priority: "high", assignees: ["DN", "JS"], category: "Foundation",
    },
    {
        id: "t2", name: "Steel Beam Delivery",
        desc: "Coordinate logistics for I-beam delivery from supplier. Confirm crane availability and receiving zone clearance.",
        status: "scheduled", schedule_pct: 40, days_remaining: 2,
        priority: "high", assignees: ["SL"], category: "Logistics",
    },
    {
        id: "t3", name: "Site Preparation — Zone B",
        desc: "Clear debris, level ground, and mark survey pins for the east wing expansion footprint.",
        status: "completed", schedule_pct: 100, days_remaining: 0,
        priority: "low", assignees: ["AJ", "MW"], category: "Site Work",
    },
    {
        id: "t4", name: "Structural Assembly — Frame",
        desc: "Erect steel frame for floors 2–3 using delivered beams. Safety harness required. Engineer sign-off needed.",
        status: "scheduled", schedule_pct: 10, days_remaining: 7,
        priority: "high", assignees: ["DN", "JS", "AJ"], category: "Structural",
    },
    {
        id: "t5", name: "Safety Inspection — Walkthrough",
        desc: "Mandatory weekly site walkthrough by Safety Officer. Checklist includes PPE compliance, scaffolding stability, and fire exits.",
        status: "review", schedule_pct: 70, days_remaining: 1,
        priority: "high", assignees: ["SL"], category: "Safety",
    },
    {
        id: "t6", name: "Electrical Rough-In — Level 1",
        desc: "Install conduit runs and junction boxes per approved electrical plan. Coordinate with structural to avoid conflicts.",
        status: "scheduled", schedule_pct: 5, days_remaining: 10,
        priority: "med", assignees: ["MW"], category: "MEP",
    },
    {
        id: "t7", name: "Plumbing Rough-In",
        desc: "Run supply and waste lines through open framing before wall close-in. Pressure test required prior to inspection.",
        status: "scheduled", schedule_pct: 0, days_remaining: 12,
        priority: "med", assignees: ["JS"], category: "MEP",
    },
    {
        id: "t8", name: "Quality Control Audit",
        desc: "Third-party QC review of all completed foundation and structural work. Documentation to be uploaded to project module.",
        status: "review", schedule_pct: 60, days_remaining: 4,
        priority: "med", assignees: ["DN", "SL"], category: "QA / QC",
    },
    {
        id: "t9", name: "Material Procurement — Phase 2",
        desc: "Issue POs for roofing, insulation, and window systems. Confirm lead times with project timeline.",
        status: "completed", schedule_pct: 100, days_remaining: 0,
        priority: "low", assignees: ["AJ"], category: "Procurement",
    },
];

/** Kanban column ids — must match HTML col-* / cards-* ids */
const KANBAN_COLUMN_STATUSES = new Set(["scheduled", "in_progress", "review", "completed"]);

/**
 * Map dashboard API / legacy task.status values onto Kanban column ids.
 * API uses due_today, pending, etc.; Kanban only recognises four columns.
 */
function normalizeTaskForKanban(task) {
    const out = { ...task };
    const pct = Math.min(100, Math.max(0, Number(out.schedule_pct) || 0));
    out.schedule_pct = pct;
    let s = String(out.status || "").toLowerCase();

    if (s === "completed" || pct >= 100) {
        out.status = "completed";
        if (pct >= 100) out.schedule_pct = 100;
        return out;
    }
    if (s === "due_today") {
        out.status = "in_progress";
        return out;
    }
    if (s === "pending") {
        out.status = "scheduled";
        return out;
    }
    if (KANBAN_COLUMN_STATUSES.has(s)) {
        out.status = s;
        return out;
    }
    out.status = "scheduled";
    return out;
}

function normalizeTaskList(arr) {
    return (arr || []).map(t => normalizeTaskForKanban({ ...t }));
}

// ── localStorage persistence (scoped per active project) ─────────────

/**
 * Write the current tasks array to localStorage so it survives
 * page refreshes.  Called after every mutation.
 */
function saveTasks() {
    try {
        localStorage.setItem(getRpTasksStorageKey(), JSON.stringify(tasks));
    } catch (e) { /* storage quota / private-browsing — silently ignore */ }
}

/**
 * Return saved tasks from localStorage, or the static TASK_SEED if
 * nothing has been saved yet (first visit) or the data is corrupt.
 */
function loadTasks() {
    try {
        const raw = localStorage.getItem(getRpTasksStorageKey());
        if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) return normalizeTaskList(parsed);
        }
    } catch (e) { /* corrupt JSON — fall through to seed */ }
    return normalizeTaskList(JSON.parse(JSON.stringify(TASK_SEED)));
}

// ── Mutable runtime state ────────────────────────────────────────────
let tasks                = loadTasks();   // ← restores persisted tasks on load
let dragId               = null;
let activeModalId        = null;
let activePriorityFilter = "all";
let searchQuery          = "";

/* ================================================================== */
/*  Kanban Board Renderer                                               */
/* ================================================================== */

const CATEGORY_ICONS = {
    "Foundation":  "🏗️",
    "Logistics":   "🚛",
    "Site Work":   "⛏️",
    "Structural":  "🔩",
    "Safety":      "⚠️",
    "MEP":         "⚡",
    "QA / QC":     "✅",
    "Procurement": "📦",
};

/** Re-render all four Kanban columns based on current state. */
function renderBoard() {
    ["scheduled", "in_progress", "review", "completed"].forEach(colId => {
        const container = document.getElementById(`cards-${colId}`);
        const countEl   = document.getElementById(`count-${colId}`);
        if (!container || !countEl) return;

        container.innerHTML = "";

        const colTasks = tasks.filter(t => {
            if (t.status !== colId) return false;
            if (activePriorityFilter !== "all" && t.priority !== activePriorityFilter) return false;
            if (searchQuery && !t.name.toLowerCase().includes(searchQuery)) return false;
            return true;
        });

        countEl.textContent = colTasks.length;
        colTasks.forEach(task => container.appendChild(buildCard(task)));
    });
}

/** Build a single draggable task card DOM element. */
function buildCard(task) {
    const card = document.createElement("div");
    card.className = "task-card";
    card.setAttribute("draggable", "true");
    card.dataset.id = task.id;

    card.addEventListener("dragstart", e => onDragStart(e, task.id));
    card.addEventListener("dragend",   onDragEnd);
    card.addEventListener("click",     () => openModal(task.id));

    const prioClass = { high:"prio-high", med:"prio-med", low:"prio-low" }[task.priority];
    const prioLabel = { high:"High",      med:"Medium",   low:"Low"      }[task.priority];

    const daysClass = task.status === "completed" ? "days-done"
                    : task.days_remaining <= 1    ? "days-urgent"
                    : task.days_remaining <= 4    ? "days-soon"
                    : "days-ok";

    const daysLabel = task.status === "completed" ? "Done"
                    : task.days_remaining === 0   ? "Due Today"
                    : task.days_remaining === 1   ? "1 Day Left"
                    : `${task.days_remaining} Days`;

    const barColor  = task.status === "completed" ? "var(--accent-green)"
                    : task.schedule_pct >= 80     ? "var(--accent-blue)"
                    : task.schedule_pct >= 40     ? "var(--accent-orange)"
                    : "var(--accent-red)";

    const catIcon   = CATEGORY_ICONS[task.category] || "📋";
    const avatars   = task.assignees.map(a => `<div class="mini-avatar">${a}</div>`).join("");

    card.innerHTML = `
        <div class="task-top">
            <div class="task-name">${task.name}</div>
            <span class="priority-badge ${prioClass}">${prioLabel}</span>
        </div>
        <div class="task-desc">${task.desc.substring(0, 80)}…</div>
        <div class="task-progress-wrap">
            <div class="task-progress-label">
                <span>Schedule</span>
                <span>${task.schedule_pct}%</span>
            </div>
            <div class="progress-track">
                <div class="progress-fill" style="width:${task.schedule_pct}%;background:${barColor};"></div>
            </div>
        </div>
        <div class="task-footer">
            <div class="task-meta">
                <div class="meta-pill">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    ${catIcon} ${task.category}
                </div>
            </div>
            <div style="display:flex;align-items:center;gap:0.5rem;">
                <div class="task-assignees">${avatars}</div>
                <span class="days-pill ${daysClass}">${daysLabel}</span>
            </div>
        </div>
    `;

    return card;
}

/* ================================================================== */
/*  Drag and Drop                                                       */
/* ================================================================== */

function onDragStart(e, id) {
    dragId = id;
    e.target.classList.add("drag-ghost");
    e.dataTransfer.effectAllowed = "move";
}

function onDragEnd(e) {
    e.target.classList.remove("drag-ghost");
    document.querySelectorAll(".kanban-col").forEach(c => c.classList.remove("drag-over"));
}

function onDragOver(e, colId) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    document.getElementById(`col-${colId}`).classList.add("drag-over");
}

function onDragLeave(e) {
    e.currentTarget.classList.remove("drag-over");
}

function onDrop(e, colId) {
    e.preventDefault();
    e.currentTarget.classList.remove("drag-over");
    if (!dragId) return;

    const task = tasks.find(t => String(t.id) === String(dragId));
    if (task && task.status !== colId) {
        task.status = colId;
        if (colId === "completed") task.schedule_pct = 100;
        saveTasks();
        showToast(`"${task.name}" moved to ${colId.replace("_", " ")}`, "success");
        renderBoard();
    }
    dragId = null;
}

// Expose drag handlers to HTML ondragover / ondrop attributes
window.onDragOver  = onDragOver;
window.onDragLeave = onDragLeave;
window.onDrop      = onDrop;

/* ================================================================== */
/*  Task Detail / Edit Modal                                            */
/* ================================================================== */

/**
 * Populate the view-mode <p> elements and open the modal.
 * Always opens in view mode (editing class removed).
 */
function openModal(id) {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    activeModalId = id;

    // Ensure we start in view mode
    document.getElementById("taskModalInner").classList.remove("editing");

    // Populate view-mode display fields
    document.getElementById("modalTitle").textContent    = task.name;
    document.getElementById("modalDesc").textContent     = task.desc;
    document.getElementById("modalStatus").textContent   = `Schedule ${task.schedule_pct}% Complete`;
    document.getElementById("modalDays").textContent     = task.status === "completed" ? "Completed ✓" : `${task.days_remaining} day(s)`;
    document.getElementById("modalPriority").textContent = { high:"High 🔴", med:"Medium 🟡", low:"Low 🟢" }[task.priority];
    document.getElementById("modalAssigned").textContent = task.assignees.join(", ");
    document.getElementById("modalProgressBar").style.width = `${task.schedule_pct}%`;

    document.getElementById("taskModal").classList.add("open");
}

/**
 * Switch the modal into edit mode:
 * - Populates all edit-mode <input>/<select>/<textarea> fields from the task
 * - Adds "editing" class to the modal inner div, which CSS uses to swap
 *   .view-only → hidden and .edit-only → visible
 */
function enterEditMode() {
    const task = tasks.find(t => t.id === activeModalId);
    if (!task) return;

    document.getElementById("ed-name").value      = task.name;
    document.getElementById("ed-desc").value      = task.desc === "No description provided." ? "" : task.desc;
    document.getElementById("ed-pct").value       = task.schedule_pct;
    document.getElementById("ed-days").value      = task.days_remaining;
    document.getElementById("ed-priority").value  = task.priority;
    document.getElementById("ed-assignees").value = task.assignees.join(", ");
    document.getElementById("ed-category").value  = task.category;
    document.getElementById("ed-status").value    = task.status;

    // Clear any leftover validation state
    document.getElementById("ed-name").classList.remove("field-error");
    document.getElementById("ed-name-err").classList.remove("visible");

    document.getElementById("taskModalInner").classList.add("editing");
    setTimeout(() => document.getElementById("ed-name").focus(), 60);
}

/** Return to view mode without saving (cancel). */
function exitEditMode() {
    document.getElementById("taskModalInner").classList.remove("editing");
}

/**
 * Validate edit-mode fields, write the changes back into the tasks array,
 * refresh both the modal view and the Kanban board, and PATCH to the API.
 */
function saveTaskEdits() {
    const nameEl = document.getElementById("ed-name");
    const name   = nameEl.value.trim();

    if (!name) {
        nameEl.classList.add("field-error");
        document.getElementById("ed-name-err").classList.add("visible");
        nameEl.focus();
        return;
    }
    nameEl.classList.remove("field-error");
    document.getElementById("ed-name-err").classList.remove("visible");

    const task = tasks.find(t => t.id === activeModalId);
    if (!task) return;

    const rawAssignees = document.getElementById("ed-assignees").value;
    const assignees = rawAssignees
        .split(",")
        .map(s => s.trim().toUpperCase())
        .filter(s => s.length > 0);

    // Write all edited values back to the task object
    task.name           = name;
    task.desc           = document.getElementById("ed-desc").value.trim() || "No description provided.";
    task.schedule_pct   = Math.min(100, Math.max(0, parseInt(document.getElementById("ed-pct").value,  10) || 0));
    task.days_remaining = Math.max(0,   parseInt(document.getElementById("ed-days").value, 10) || 0);
    task.priority       = document.getElementById("ed-priority").value;
    task.assignees      = assignees.length ? assignees : task.assignees;
    task.category       = document.getElementById("ed-category").value;
    task.status         = document.getElementById("ed-status").value;

    // Snap completed tasks to 100 %
    if (task.status === "completed") task.schedule_pct = 100;
    saveTasks();

    // Switch back to view mode and refresh the view-mode display
    exitEditMode();
    openModal(activeModalId); // re-populates view fields with new values

    // Re-render the board so the card reflects the edits immediately
    renderBoard();
    showToast(`"${task.name}" updated`, "success");

    // Non-blocking PATCH — task is already updated locally if API is unavailable
    fetch(rpApiUrl(`/api/dashboard/tasks/${task.id}`), {
        method:  "PATCH",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(task),
    }).catch(() => {});
}

function closeModal() {
    document.getElementById("taskModal").classList.remove("open");
    document.getElementById("taskModalInner").classList.remove("editing");
    activeModalId = null;
}

function markDone() {
    if (!activeModalId) return;
    const task = tasks.find(t => t.id === activeModalId);
    if (task) {
        task.status       = "completed";
        task.schedule_pct = 100;
        saveTasks();
        showToast(`"${task.name}" marked as complete ✓`, "success");
        renderBoard();
    }
    closeModal();
}

// Expose modal handlers called from HTML attributes
window.openModal      = openModal;
window.closeModal     = closeModal;
window.markDone       = markDone;
window.enterEditMode  = enterEditMode;
window.exitEditMode   = exitEditMode;
window.saveTaskEdits  = saveTaskEdits;

/* ================================================================== */
/*  Search and Filter                                                   */
/* ================================================================== */

/** Live search — called by input oninput handler in HTML. */
function filterCards(q) {
    searchQuery = q.toLowerCase().trim();
    renderBoard();
}

/** Priority chip filter — called by button onclick handlers in HTML. */
function filterByPriority(prio, btn) {
    activePriorityFilter = prio;
    document.querySelectorAll(".filter-chip").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    renderBoard();
}

window.filterCards      = filterCards;
window.filterByPriority = filterByPriority;

/* ================================================================== */
/*  Add Task Modal                                                      */
/* ================================================================== */

function openAddTaskModal() {
    document.getElementById("at-name").value      = "";
    document.getElementById("at-desc").value      = "";
    document.getElementById("at-category").value  = "Foundation";
    document.getElementById("at-priority").value  = "med";
    document.getElementById("at-status").value    = "scheduled";
    document.getElementById("at-days").value      = "7";
    document.getElementById("at-pct").value       = "0";
    document.getElementById("at-assignees").value = "";

    document.getElementById("at-name").classList.remove("field-error");
    document.getElementById("at-name-err").classList.remove("visible");

    document.getElementById("addTaskModal").classList.add("open");
    setTimeout(() => document.getElementById("at-name").focus(), 60);
}

function closeAddTaskModal() {
    document.getElementById("addTaskModal").classList.remove("open");
}

function submitAddTask() {
    const nameEl = document.getElementById("at-name");
    const name   = nameEl.value.trim();

    if (!name) {
        nameEl.classList.add("field-error");
        document.getElementById("at-name-err").classList.add("visible");
        nameEl.focus();
        return;
    }
    nameEl.classList.remove("field-error");
    document.getElementById("at-name-err").classList.remove("visible");

    const rawAssignees = document.getElementById("at-assignees").value;
    const assignees = rawAssignees
        .split(",")
        .map(s => s.trim().toUpperCase())
        .filter(s => s.length > 0);
    if (assignees.length === 0) assignees.push("DN");

    const days = Math.max(0, parseInt(document.getElementById("at-days").value, 10) || 0);
    const pct  = Math.min(100, Math.max(0, parseInt(document.getElementById("at-pct").value, 10) || 0));

    const newTask = {
        id:             "t" + Date.now(),
        name:           name,
        desc:           document.getElementById("at-desc").value.trim() || "No description provided.",
        status:         document.getElementById("at-status").value,
        schedule_pct:   pct,
        days_remaining: days,
        priority:       document.getElementById("at-priority").value,
        assignees:      assignees,
        category:       document.getElementById("at-category").value,
    };

    tasks.push(newTask);
    saveTasks();
    renderBoard();
    closeAddTaskModal();
    showToast(`"${newTask.name}" added to ${newTask.status.replace("_", " ")}`, "success");

    fetch(rpApiUrl("/api/dashboard/tasks"), {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(newTask),
    }).catch(() => {});
}

// Close on backdrop click or Escape
document.addEventListener("click", e => {
    const overlay = document.getElementById("addTaskModal");
    if (overlay && e.target === overlay) closeAddTaskModal();
});
document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
        closeAddTaskModal();
    }
});

window.openAddTaskModal  = openAddTaskModal;
window.closeAddTaskModal = closeAddTaskModal;
window.submitAddTask     = submitAddTask;

/* ================================================================== */
/*  Nav helpers — user menu, logout modal                              */
/* ================================================================== */

function toggleUserMenu() {
    document.getElementById("userDropdown").classList.toggle("open");
}

function showLogoutModal() {
    document.getElementById("userDropdown").classList.remove("open");
    document.getElementById("logoutOverlay").classList.add("open");
}

function hideLogoutModal() {
    document.getElementById("logoutOverlay").classList.remove("open");
}

function confirmLogout() {
    window.location.href = "/login?signedout=1";
}

// Expose nav helpers called from HTML onclick attributes
window.toggleUserMenu  = toggleUserMenu;
window.showLogoutModal = showLogoutModal;
window.hideLogoutModal = hideLogoutModal;
window.confirmLogout   = confirmLogout;

// Close user dropdown when clicking outside
document.addEventListener("click", e => {
    const wrap = document.querySelector(".user-menu-wrap");
    if (wrap && !wrap.contains(e.target)) {
        document.getElementById("userDropdown")?.classList.remove("open");
    }
});

/* ================================================================== */
/*  Init                                                                */
/* ================================================================== */

/**
 * Fetch tasks from the API; fall back to TASK_SEED if unavailable.
 * Then render the Kanban board.
 */
/**
 * Fetch tasks from the API and re-render the board if live data is returned.
 *
 * IMPORTANT: renderBoard() is called immediately with seed data BEFORE this
 * async function is awaited — so the board is always populated on first paint.
 * This function only updates the board if the server responds with real tasks.
 */
async function syncTasksFromAPI() {
    const beforeSync = tasks.slice();
    let hadSavedBoard = false;
    try {
        const raw = localStorage.getItem(getRpTasksStorageKey());
        if (raw) {
            const parsed = JSON.parse(raw);
            hadSavedBoard = Array.isArray(parsed) && parsed.length > 0;
        }
    } catch {
        hadSavedBoard = false;
    }

    try {
        const res  = await fetch(rpApiUrl("/api/dashboard/tasks"));
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();

        if (json.data?.length) {
            const localById = new Map(beforeSync.map(t => [String(t.id), t]));

            const newTasks = json.data.map((t, i) => {
                const id = t.id ?? `api-${i}`;
                const normalized = normalizeTaskForKanban({
                    id:             id,
                    name:           t.name,
                    desc:           t.description ?? t.desc ?? "No description provided.",
                    status:         t.status ?? "scheduled",
                    schedule_pct:   t.schedule_pct ?? 0,
                    days_remaining: t.days_remaining ?? 0,
                    priority:       t.priority ?? "med",
                    assignees:      Array.isArray(t.assignees) && t.assignees.length ? t.assignees : ["DN"],
                    category:       t.category ?? "General",
                });
                /* Drag-and-drop column is stored locally; API dates do not match Kanban columns */
                const loc = localById.get(String(id));
                if (loc && KANBAN_COLUMN_STATUSES.has(loc.status)) {
                    return normalizeTaskForKanban({ ...normalized, status: loc.status });
                }
                return normalized;
            });

            const apiIds = new Set(newTasks.map(t => String(t.id)));
            let extras;
            if (hadSavedBoard) {
                /* Keep any local-only rows (e.g. tasks not returned by GET /tasks) */
                extras = beforeSync.filter(t => !apiIds.has(String(t.id)));
            } else {
                /* First load: only merge seed cards in review/completed not in API (demo data) */
                extras = beforeSync.filter(
                    t =>
                        (t.status === "review" || t.status === "completed") &&
                        !apiIds.has(String(t.id))
                );
            }

            tasks = [...newTasks, ...normalizeTaskList(extras)];
            saveTasks();
            renderBoard();
            showToast("Tasks loaded from server", "success");
        }
        // API returned no data → seed-data board is already showing, do nothing
    } catch {
        // API unavailable → seed-data board is already showing, do nothing
    }
}

/**
 * Main entry point: Kanban first paint, then optional API upgrade.
 *
 * WHY readyState CHECK (at bottom of file):
 *   Scripts at the bottom of <body> execute after the DOM is parsed, meaning
 *   DOMContentLoaded has already fired. addEventListener("DOMContentLoaded")
 *   at that point registers a callback that is never invoked. The readyState
 *   guard handles both cases: early load (wait for event) and late load (call
 *   directly).
 */
async function init() {
    await loadResourcePlanProjectSwitcher();
    updateResourcePlanNavLinks();
    tasks = loadTasks();
    renderBoard();
    await syncTasksFromAPI();
}

function runInit() {
    init().catch(err => console.error("[Resource Plan] Init error:", err));
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", runInit);
} else {
    runInit();
}
})(); // end resource_plan IIFE