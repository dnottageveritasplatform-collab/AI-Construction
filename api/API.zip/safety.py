"""
api/safety.py
-------------
REST API endpoints for the Safety Monitor module.
Base path: /api/safety

UC-03: All alert data is derived from real project gantt tasks via
_generate_project_alerts() shared from api.dashboard.  No mock data.
The Safety Module and the Dashboard widget always show identical alerts.
"""

from flask              import Blueprint, jsonify, request
from datetime           import datetime

# Share the exact same alert engine as the dashboard widget (UC-03).
# This guarantees the Safety Module and dashboard widget are always in sync.
from api.dashboard import (
    _generate_project_alerts,
    _resolve_project_id as _dash_pid,
)

safety_bp = Blueprint("safety", __name__, url_prefix="/api/safety")


def _resolve_project_id() -> str:
    return _dash_pid()


# In-memory acknowledged-alert store (per-process; resets on restart).
# Production: replace with a DB table.
_ACKNOWLEDGED: dict = {}


# ---------------------------------------------------------------------------
# GET /api/safety/alerts?project_id=&severity=&zone=
# ---------------------------------------------------------------------------
@safety_bp.route("/alerts", methods=["GET"])
def get_alerts():
    project_id = _resolve_project_id()
    severity   = request.args.get("severity", "all").lower()
    zone_q     = request.args.get("zone",     "all").lower()

    alerts = _generate_project_alerts(project_id)

    # Apply in-memory acknowledgement state
    for a in alerts:
        if a["id"] in _ACKNOWLEDGED:
            a.update(_ACKNOWLEDGED[a["id"]])

    if severity != "all":
        alerts = [a for a in alerts if a["severity"] == severity]
    if zone_q != "all":
        alerts = [a for a in alerts if zone_q in a["zone"].lower()]

    return jsonify({
        "status":         "ok",
        "project_id":     project_id,
        "total":          len(alerts),
        "critical_count": sum(1 for a in alerts if a["severity"] == "critical"),
        "data":           alerts,
    })


# ---------------------------------------------------------------------------
# GET /api/safety/alerts/<alert_id>?project_id=
# ---------------------------------------------------------------------------
@safety_bp.route("/alerts/<alert_id>", methods=["GET"])
def get_alert_detail(alert_id):
    project_id = _resolve_project_id()
    alerts     = _generate_project_alerts(project_id)
    alert      = next((a for a in alerts if a["id"] == alert_id), None)

    if not alert:
        return jsonify({"status": "error", "message": "Alert not found"}), 404

    if alert_id in _ACKNOWLEDGED:
        alert.update(_ACKNOWLEDGED[alert_id])

    return jsonify({"status": "ok", "data": alert})


# ---------------------------------------------------------------------------
# POST /api/safety/alerts/<alert_id>/acknowledge
# ---------------------------------------------------------------------------
@safety_bp.route("/alerts/<alert_id>/acknowledge", methods=["POST"])
def acknowledge_alert(alert_id):
    project_id = _resolve_project_id()
    alerts     = _generate_project_alerts(project_id)
    alert      = next((a for a in alerts if a["id"] == alert_id), None)

    if not alert:
        return jsonify({"status": "error", "message": "Alert not found"}), 404

    ack = {
        "acknowledged":    True,
        "acknowledged_at": datetime.now().strftime("%H:%M:%S"),
        "acknowledged_by": "usr-001",
    }
    _ACKNOWLEDGED[alert_id] = ack
    alert.update(ack)

    return jsonify({
        "status":  "ok",
        "message": f"Alert {alert_id} acknowledged.",
        "data":    alert,
    })


# ---------------------------------------------------------------------------
# GET /api/safety/zones?project_id=
# Derives zone status from live alert counts
# ---------------------------------------------------------------------------
@safety_bp.route("/zones", methods=["GET"])
def get_zones():
    project_id = _resolve_project_id()
    alerts     = _generate_project_alerts(project_id)

    for a in alerts:
        if a["id"] in _ACKNOWLEDGED:
            a.update(_ACKNOWLEDGED[a["id"]])

    # Count unacknowledged alerts per zone
    zone_counts: dict = {}
    for a in alerts:
        if a.get("acknowledged"):
            continue
        z = a["zone"]
        if z not in zone_counts:
            zone_counts[z] = {"critical": 0, "warning": 0}
        zone_counts[z][a["severity"]] = zone_counts[z].get(a["severity"], 0) + 1

    default_zones = [
        {"id": "Z1", "name": "Zone 1 \u2013 Foundation",   "camera": "CAM-01"},
        {"id": "Z2", "name": "Zone 2 \u2013 Material Bay",  "camera": "CAM-02"},
        {"id": "Z3", "name": "Zone 3 \u2013 West Wing",     "camera": "CAM-03"},
        {"id": "Z4", "name": "Zone 4 \u2013 East Wing",     "camera": "CAM-04"},
    ]

    result = []
    for z in default_zones:
        counts = zone_counts.get(z["name"], {})
        crits  = counts.get("critical", 0)
        warns  = counts.get("warning",  0)
        status = "critical" if crits > 0 else ("warning" if warns > 0 else "clear")
        result.append({**z, "status": status, "active_alerts": crits + warns})

    return jsonify({"status": "ok", "data": result})